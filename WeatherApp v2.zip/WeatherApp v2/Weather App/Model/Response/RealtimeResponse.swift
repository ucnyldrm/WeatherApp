//
//  RealtimeResponse.swift
//  Weather App
//
//  Created by Can Yıldırım on 9.01.24.
//

import Foundation

struct RealtimeResponse: Codable {
    let data: DataClass
    let location: RealtimeLocation
}

struct DataClass: Codable {
    let time: String
    let values: [String: Double?]
}

struct RealtimeLocation: Codable {
    let lat, lon: Double
    let name, type: String
}
