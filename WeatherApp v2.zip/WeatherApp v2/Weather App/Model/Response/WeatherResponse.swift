//
//  WeatherResponse.swift
//  Weather App
//
//  Created by Can Yıldırım on 3.01.24.
//

import Foundation


struct WeatherResponse: Codable {
    let timelines: Timelines
    let location: Location
}

struct Location: Codable {
    let lat, lon: Double
    let name, type: String
}

struct Timelines: Codable {
    let minutely: [Minutely]
    let hourly: [Hourly]
    let daily: [Daily]
}

struct Daily: Codable {
    let time: String
    let values: Values
}

struct Values: Codable {
    let cloudBaseAvg, cloudBaseMax, cloudBaseMin, cloudCeilingAvg: Double
    let cloudCeilingMax, cloudCeilingMin, cloudCoverAvg: Double
    let cloudCoverMax: Double
    let cloudCoverMin, dewPointAvg, dewPointMax, dewPointMin: Double
    let evapotranspirationAvg, evapotranspirationMax, evapotranspirationMin, evapotranspirationSum: Double
    let freezingRainIntensityAvg: Double
    let freezingRainIntensityMax: Double
    let freezingRainIntensityMin: Double
    let humidityAvg, humidityMax, humidityMin: Double
    let iceAccumulationAvg, iceAccumulationLweAvg: Double
    let iceAccumulationLweMax: Double
    let iceAccumulationLweMin: Double
    let iceAccumulationLweSum: Double
    let iceAccumulationMax, iceAccumulationMin, iceAccumulationSum: Double
    let moonriseTime, moonsetTime: String?
    let precipitationProbabilityAvg: Double
    let precipitationProbabilityMax, precipitationProbabilityMin: Double
    let pressureSurfaceLevelAvg, pressureSurfaceLevelMax, pressureSurfaceLevelMin: Double
    let rainAccumulationAvg: Double
    let rainAccumulationLweAvg, rainAccumulationLweMax: Double
    let rainAccumulationLweMin, rainAccumulationMax, rainAccumulationMin, rainAccumulationSum: Double
    let rainIntensityAvg, rainIntensityMax: Double
    let rainIntensityMin, sleetAccumulationAvg, sleetAccumulationLweAvg, sleetAccumulationLweMax: Double
    let sleetAccumulationLweMin, sleetAccumulationLweSum, sleetAccumulationMax, sleetAccumulationMin: Double
    let sleetIntensityAvg, sleetIntensityMax, sleetIntensityMin: Double
    let snowAccumulationAvg, snowAccumulationLweAvg, snowAccumulationLweMax: Double
    let snowAccumulationLweMin: Double
    let snowAccumulationLweSum, snowAccumulationMax, snowAccumulationMin, snowAccumulationSum: Double
    let snowIntensityAvg, snowIntensityMax, snowIntensityMin: Double
    let sunriseTime, sunsetTime: String
    let temperatureApparentAvg, temperatureApparentMax, temperatureApparentMin, temperatureAvg: Double
    let temperatureMax, temperatureMin: Double
    let uvHealthConcernAvg, uvHealthConcernMax, uvHealthConcernMin, uvIndexAvg: Double?
    let uvIndexMax, uvIndexMin: Double?
    let visibilityAvg, visibilityMax, visibilityMin: Double
    let weatherCodeMax, weatherCodeMin: Double
    let windDirectionAvg, windGustAvg, windGustMax, windGustMin: Double
    let windSpeedAvg, windSpeedMax, windSpeedMin: Double
}

struct Hourly: Codable {
    let time: String
    let values: [String: Double?]
}

struct Minutely: Codable {
    let time: String
    let values: [String: Double?]
}



