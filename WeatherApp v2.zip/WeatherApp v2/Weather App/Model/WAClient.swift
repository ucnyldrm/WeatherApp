//
//  WAClient.swift
//  Weather App
//
//  Created by Can Yıldırım on 3.01.24.
//

import Foundation

class WAClient {
    
    
    static let apiKey = "uqCjDYdrqrZfFr5Cp9rB4hVQJUVf0GEC"
    
    
    enum EndPoints {
        
        static let base = "https://api.tomorrow.io/v4/"
        
        case weatherForecast(String, String)
        case realtime(String)
        
        var url : URL {
            
            return URL(string: stringValue)!
            
        }
        
        var stringValue : String {
            
            switch self {
                
            case .weatherForecast(let location, let units) : return EndPoints.base + "weather/forecast?location=" + (location.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? location) + "&units=" + units + "&apikey=\(WAClient.apiKey)"
            case .realtime(let location) : return EndPoints.base + "weather/realtime?location=" + (location.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? location) + "&apikey=\(WAClient.apiKey)"
            
            }
            
        }
    
    }
    
    class func realtime(location: String, completion: @escaping (RealtimeResponse?, Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.realtime(location).url, responseType: RealtimeResponse.self) { data, error in
            
            if let data = data {
                
                completion(data, nil)
                
            } else {
                
                completion(nil, error)
                
            }
            
        }
        
    }
    
    class func weatherForecast(location: String, units: String, completion: @escaping (WeatherResponse?, Error?) -> Void) {
        
        taskForGetRequest(url: EndPoints.weatherForecast(location, units).url, responseType: WeatherResponse.self) { data, error in
            
            if let data = data {
                
                completion(data, nil)
                
            } else {
                
                completion(nil, error)
            }
            
        }
        
    }
        
    class func taskForGetRequest<ResponseType: Decodable> (url: URL, responseType: ResponseType.Type, completion: @escaping (ResponseType?, Error?) -> Void) {
            
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                
                guard let data = data else {
                    
                    DispatchQueue.main.sync {
                        
                        completion(nil, error)
                        
                    }
                    return
                }

                    let headers = [
                      "accept": "application/json",
                      "Accept-Encoding": "gzip"
                    ]

                let request = NSMutableURLRequest(url: NSURL(string: url.absoluteString)! as URL, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 10.0)
                    
                    request.httpMethod = "GET"
                    request.allHTTPHeaderFields = headers
                
                let decoder = JSONDecoder()
                
                do {
                    
                    let response = try decoder.decode(ResponseType.self, from: data)
                    
                    DispatchQueue.main.sync {
                        
                        completion(response, nil)
                        
                    }
                    
                } catch {
                    
                    DispatchQueue.main.sync {
                        
                        completion(nil, error)
                        
                    }
                    
                }
                
            }
            
            task.resume()
    
    }
        
}
    
    
