//
//  WearchViewController.swift
//  Weather App
//
//  Created by Can Yıldırım on 31.12.23.
//

import UIKit
import GooglePlaces
    

class SearchViewController: UIViewController {
    

  @IBOutlet weak var tableView: UITableView!
  @IBOutlet weak var searchBar: UISearchBar!
  
    
  private var tableDataSource: GMSAutocompleteTableDataSource!


  override func viewDidLoad() {
    super.viewDidLoad()

    tableDataSource = GMSAutocompleteTableDataSource()
    tableDataSource.delegate = self
    tableDataSource.tableCellBackgroundColor = .clear

    tableView.delegate = tableDataSource
    tableView.dataSource = tableDataSource

  }

}

extension SearchViewController: UISearchBarDelegate {
  func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {

      tableDataSource.sourceTextHasChanged(searchText)
  }
    
}

extension SearchViewController: GMSAutocompleteTableDataSourceDelegate {
  func didUpdateAutocompletePredictions(for tableDataSource: GMSAutocompleteTableDataSource) {

      UIApplication.shared.isNetworkActivityIndicatorVisible = false
    
      tableView.reloadData()
  }

  func didRequestAutocompletePredictions(for tableDataSource: GMSAutocompleteTableDataSource) {

      UIApplication.shared.isNetworkActivityIndicatorVisible = true

      tableView.reloadData()
  }

  func tableDataSource(_ tableDataSource: GMSAutocompleteTableDataSource, didAutocompleteWith place: GMSPlace) {
      
      let weatherVC = storyboard?.instantiateViewController(identifier: "weatherViewController") as! WeatherViewController
      
      weatherVC.city = place.name ?? "-"
      weatherVC.utcOffset = place.utcOffsetMinutes!.intValue
      
      navigationController?.pushViewController(weatherVC, animated: true)
      present(weatherVC, animated: true)

  }

  func tableDataSource(_ tableDataSource: GMSAutocompleteTableDataSource, didFailAutocompleteWithError error: Error) {
      
    print("Error: \(error.localizedDescription)")
      
  }

}

