//
//  WeatherViewController.swift
//  Weather App
//
//  Created by Can Yıldırım on 5.01.24.
//

import UIKit
import SkeletonView

class WeatherViewController : UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var temperatureAvg: UILabel!
    @IBOutlet weak var descriptionOfWeather: UILabel!
    @IBOutlet weak var temperatureMinandMax: UILabel!
    @IBOutlet weak var imageOfdescription: UIImageView!
    @IBOutlet weak var dailyWeatherLabel: UILabel!
    @IBOutlet weak var windSpeedLabel: UILabel!
    @IBOutlet weak var windGustLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var dewPointLabel: UILabel!
    @IBOutlet weak var uvIndexLabel: UILabel!
    @IBOutlet weak var feelsLikeLabel: UILabel!
    @IBOutlet weak var visibilityLabel: UILabel!
    @IBOutlet weak var pressureLabel: UILabel!
    @IBOutlet weak var upStackView: UIStackView!
    @IBOutlet weak var downStackView: UIStackView!
    
    var city = String()
    var utcOffset = Int()
    var dailyWeatherMin = [Double]()
    var dailyWeatherMax = [Double]()
    
    override func viewDidLoad() {
        
        cityLabel.text = city
        weatherRealTime()
        weatherDailyandHourly()
        startSkeleton(view: dailyWeatherLabel)
        setSkeletonView(stackViews: [downStackView, upStackView], image: imageOfdescription)

    }

    func setSkeletonView(stackViews: [UIStackView], image: UIImageView) {
        
        SkeletonAppearance.default.skeletonCornerRadius = 10

        for stackView in stackViews {

            setAnimation(views: [stackView, image])

        }
        
        func setAnimation(views: [UIView]) {
            
            for view in views {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    view.stopSkeletonAnimation()
                    view.hideSkeleton()
                }
             
             startSkeleton(view: view)
              
            }
        }
    }
    
    func startSkeleton(view: UIView) {
        
        view.isSkeletonable = true
        view.startSkeletonAnimation()
        view.showAnimatedGradientSkeleton(usingGradient: .init(baseColor: .silver), animation: nil, transition: .crossDissolve(0.25))
        
    }

    func weatherDailyandHourly() {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E"
        dateFormatter.locale = Locale(identifier: "en_US")
            
            WAClient.weatherForecast(location: self.city, units: "metric") { data, error in
                
                if let data = data {
                    
                    self.dailyWeatherLabel.stopSkeletonAnimation()
                    self.dailyWeatherLabel.hideSkeleton()
                    
                    for daily in data.timelines.daily {
                        
                        self.dailyWeatherMin.append(daily.values.temperatureMin)
                        self.dailyWeatherMax.append(daily.values.temperatureMax)
                        
                        self.temperatureMinandMax.text = "H:\(Int(self.dailyWeatherMax[0].rounded()))° L:\(Int(self.dailyWeatherMin[0].rounded()))°"
                        
                    }
                    
                    self.dailyWeatherLabel.text = "Today \(Int(self.dailyWeatherMin[0]))°/\(Int(self.dailyWeatherMax[0].rounded()))°, \(self.getNextDays(value: 1)) \(Int(self.dailyWeatherMin[1]))°/\(Int(self.dailyWeatherMax[1].rounded()))°, \(self.getNextDays(value: 2)) \(Int(self.dailyWeatherMin[2]))°/\(Int(self.dailyWeatherMax[2].rounded()))°, \(self.getNextDays(value: 3)) \(Int(self.dailyWeatherMin[3]))°/\(Int(self.dailyWeatherMax[3].rounded()))°\n \(self.getNextDays(value: 4)) \(Int(self.dailyWeatherMin[4]))°/\(Int(self.dailyWeatherMax[4].rounded()))°, \(self.getNextDays(value: 5)) \(Int(self.dailyWeatherMin[5]))°/\(Int(self.dailyWeatherMax[5].rounded()))°"
                } else {
                    
                    self.dailyWeatherLabel.stopSkeletonAnimation()
                    self.dailyWeatherLabel.hideSkeleton()
            }
        }
    }

    func weatherRealTime() {
        
        WAClient.realtime(location: city) { data, error in
            
            if let data = data {

                for d in data.data.values {
                    
                    switch d.key {
                        
                    case "temperature" : guard let value = d.value else {return self.temperatureAvg.text = "-"}
                        self.temperatureAvg.text = "\(Int(value.rounded()))°"
                    case "windSpeed" : guard let value = d.value else {return self.windSpeedLabel.text = "-"}
                        self.windSpeedLabel.text = "\(Int(value.rounded()))"
                    case "windGust" : guard let value = d.value else {return self.windGustLabel.text = "-"}
                        self.windGustLabel.text = "\(Int(value.rounded()))"
                    case "humidity" : guard let value = d.value else {return self.humidityLabel.text = "% -"}
                        self.humidityLabel.text = "%\(Int(value.rounded()))"
                    case "dewPoint" : guard let value = d.value else {return self.dewPointLabel.text = "-"}
                        self.dewPointLabel.text = "Current dew point is \(Int(value.rounded()))°"
                    case "uvIndex" : guard let value = d.value else {return self.uvIndexLabel.text = "-"}
                        self.uvIndexLabel.text = "\(Int(value.rounded()))"
                    case "temperatureApparent" : guard let value = d.value else {return self.feelsLikeLabel.text = "-"}
                        self.feelsLikeLabel.text = "\(Int(value.rounded()))°"
                    case "visibility" : guard let value = d.value else {return self.visibilityLabel.text = "- km"}
                        self.visibilityLabel.text = "\(Int(value.rounded())) km"
                    case "pressureSurfaceLevel" : guard let value = d.value else {return self.pressureLabel.text = "- hPa"}
                        self.pressureLabel.text = "\(Int(value.rounded()))\nhPa"
                
                    default : break
                    }
                    
                    if d.key == "weatherCode" {
                        
                        func setImagebyUctOffsetTime(day: UIImage?, night: UIImage?) {
                            
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "HH"
                            dateFormatter.timeZone = TimeZone(identifier: "Europe/London")
                            let calender = Calendar.current.date(byAdding: .minute, value: self.utcOffset, to: Date())

                            if let calender = calender {
                                
                                let time = dateFormatter.string(from: calender)
                                                                
                                switch time {
                                    
                                case "19","20","21","22","23","00","01","02","03","04","05" :
                                    
                                    self.imageOfdescription.image = night
                                    
                                case "06","07","08","09","10","11","12","13","14","15","16","17","18" :
                                    
                                    self.imageOfdescription.image = day
                                    
                                default:
                                    
                                    break
                                    
                                }
                                
                            }
                            
                        }
                        
                        switch d.value {
                            
                        case 0 : self.descriptionOfWeather.text = "Unknown"
                        case 1000 : self.descriptionOfWeather.text = "Clear"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "sun.max.fill"), night: UIImage(systemName: "moon.stars.fill"))
                        case 1100 : self.descriptionOfWeather.text = "Mostly Clear"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "sun.max.fill"), night: UIImage(systemName: "moon.fill"))
                        case 1101: self.descriptionOfWeather.text = "Partly Cloudy"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sun.fill"), night: UIImage(systemName: "cloud.moon.fill"))
                        case 1102: self.descriptionOfWeather.text = "Mostly Cloudy"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sun.fill"), night: UIImage(systemName: "cloud.moon.fill"))
                        case 1001: self.descriptionOfWeather.text = "Cloudy"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.fill"), night: UIImage(systemName: "cloud.fill"))
                        case 2000: self.descriptionOfWeather.text = "Fog"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "sun.haze.fill"), night: UIImage(systemName: "moon.haze.fill"))
                        case 2100: self.descriptionOfWeather.text = "Light Fog"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "sun.haze.fill"), night: UIImage(systemName: "moon.haze.fill"))
                        case 4000: self.descriptionOfWeather.text = "Drizzle"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.drizzle.fill"), night: UIImage(systemName: "cloud.drizzle.fill"))
                        case 4001: self.descriptionOfWeather.text = "Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.rain.fill"), night: UIImage(systemName: "cloud.rain.fill"))
                        case 4200: self.descriptionOfWeather.text = "Light Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sun.rain.fill"), night: UIImage(systemName: "cloud.moon.rain.fill"))
                        case 4201: self.descriptionOfWeather.text = "Heavy Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.heavyrain.fill"), night: UIImage(systemName: "cloud.heavyrain.fill"))
                        case 5000: self.descriptionOfWeather.text = "Snow"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.snow.fill"), night: UIImage(systemName: "cloud.snow.fill"))
                        case 5001: self.descriptionOfWeather.text = "Flurries"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sleet.fill"), night: UIImage(systemName: "cloud.sleet.fill"))
                        case 5100: self.descriptionOfWeather.text = "Light Snow"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.snow.fill"), night: UIImage(systemName: "cloud.snow.fill"))
                        case 5101: self.descriptionOfWeather.text = "Heavy Snow"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.snow.fill"), night: UIImage(systemName: "cloud.snow.fill"))
                        case 6000: self.descriptionOfWeather.text = "Freezing Drizzle"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.drizzle.fill"), night: UIImage(systemName: "cloud.drizzle.fill"))
                        case 6001: self.descriptionOfWeather.text = "Freezing Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.rain.fill"), night: UIImage(systemName: "cloud.rain.fill"))
                        case 6200: self.descriptionOfWeather.text = "Light Freezing Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sun.rain.fill"), night: UIImage(systemName: "cloud.moon.rain.fill"))
                        case 6201: self.descriptionOfWeather.text = "Heavy Freezing Rain"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.heavyrain.fill"), night: UIImage(systemName: "cloud.heavyrain.fill"))
                        case 7000: self.descriptionOfWeather.text = "Ice Pellets"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.hail.fill"), night: UIImage(systemName: "cloud.hail.fill"))
                        case 7101: self.descriptionOfWeather.text = "Heavy Ice Pellets"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.hail.fill"), night: UIImage(systemName: "cloud.hail.fill"))
                        case 7102: self.descriptionOfWeather.text = "Light Ice Pellets"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.hail.fill"), night: UIImage(systemName: "cloud.hail.fill"))
                        case 8000: self.descriptionOfWeather.text = "Thunderstorm"
                        setImagebyUctOffsetTime(day: UIImage(systemName: "cloud.sun.bolt.fill"), night: UIImage(systemName: "cloud.moon.bolt.fill"))
                        default:
                            break
                        }
                    }
                }
            }
        }
    }
    
    func getNextDays(value: Int) -> String {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "E"
        dateFormatter.locale = Locale(identifier: "en_US")
        let nextDay = Calendar.current.date(byAdding: .day, value: value, to: Date())!
        return dateFormatter.string(from: nextDay)
    
    }
    
}
